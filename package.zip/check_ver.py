import json
import requests

web_url = 'https://lewisdavies.me/api/product_versions.json'
up_to_date = False

# Fetch online data and load local version
online_data = requests.get(web_url).json()
local_version = json.load(open('product_info.json'))

# Get the latest version from the online data
latest_version = online_data['Products'][0]['LatestVersion']
latest_patch = online_data['Products'][0]['Versions'][0]['Patches'][-1]['PatchVersion']

# Compare major version
if latest_version > local_version['Version']:
    print('New Major Update Available!')
    print('Current Version:', local_version['Version'])
    print('Latest Version:', latest_version)
    up_to_date = "major"

# Compare patch version
elif latest_patch > local_version['Details']['Patch Version']:
    print('New Patch Available!')
    print('Current Patch Version:', local_version['Details']['Patch Version'])
    print('Latest Patch Version:', latest_patch)
    up_to_date = "patch"

else:
    up_to_date = True

if local_version['Details']['Flags']['IsDeprecated']:
    print('This version is deprecated and may not be supported. Please update to the latest version.')

# Announce in console the presence of the software
if up_to_date == True:
    print(f'{local_version["Details"]["Name"]}{" Beta Version" if local_version["Details"]["Flags"]["IsBeta"] else ""}{" Development Version" if local_version["Details"]["Flags"]["IsDev"] else ""} is up to date!')
elif up_to_date == "major":
    print(f'{local_version["Details"]["Name"]}{" Beta Version" if local_version["Details"]["Flags"]["IsBeta"] else ""}{" Development Version" if local_version["Details"]["Flags"]["IsDev"] else ""} has a major update available!')
elif up_to_date == "patch":
    print(f'{local_version["Details"]["Name"]}{" Beta Version" if local_version["Details"]["Flags"]["IsBeta"] else ""}{" Development Version" if local_version["Details"]["Flags"]["IsDev"] else ""} has a patch update available!')
else:
    print('An error occurred while checking for updates.')
